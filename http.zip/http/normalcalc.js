exports.eval=function(sinvalue){
	return eval(sinvalue);
}

