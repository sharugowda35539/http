var fs=require("fs");
var http=require("http");
var obj;
http.createServer(function (request, response) { 

var data=fs.readFile('inputjson.json','utf8',function(err,data){
			if(err)return console.error(err);
			obj=JSON.parse(data);
			console.log(obj);
 			response.writeHead(200, {'Content-Type': 'text/html'});
			response.write("output-->"+obj.name);
			response.write("<br>output-->"+obj.age);	
			response.end();
			});
}).listen(8888);

