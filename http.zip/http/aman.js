[{"name": "India ", "population": "130000000"},
 {"name": "South Africa ", "population": "50000000"},
 {"name": "US ", "population": "30000000"},
 {"name": "Nepal ", "population": "20000000"},
 {"name": "Australia ", "population": "20000000"},
 {"name": "UK ", "population": "20000000"},
];
