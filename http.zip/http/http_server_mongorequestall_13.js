var http = require('http');
var fs = require('fs');
// New Code
var mongo = require('mongodb');
var monk = require('monk');
var db = monk('localhost:27017/mydb');
var collection = db.get('itccollection'); 
//url module is required to parse the URL passed to server
var url = require('url');
http.createServer(function (request, response) {  
   //parse the pathname containing file name
var ur=url.parse(request.url,true);
   var pathname = ur.pathname;
  //print the name of the file for which request is made.
    console.log("Request for " + pathname + " received.");
   //read the requested file content from file system
   fs.readFile(pathname.substr(1), function (err, data) {
      if (err) {
         console.log(err.stack);
        response.writeHead(404, {'Content-Type': 'text/html'});
      }else{	
 response.writeHead(200, {'Content-Type': 'text/html'});	
var qr=ur.query;
if(pathname=="/result.html"){
  var ob=JSON.stringify(qr);
  if(ob.length>2){
    var obj=JSON.parse(ob)
    collection.insert({name:obj.name,password:obj.pass,email:obj.email,address:obj.address})
    response.write("Name is-->"+obj.name);
    response.write("<br>Password is-->"+obj.pass);
    response.write("<br>address is-->"+obj.address);
    response.write("<br>email is-->"+obj.email);
    response.write("<a href=login.html>Login</a>");
}
}
if(pathname=="/loginresult.html"){
  var ob=JSON.stringify(qr);
  if(ob.length>2){
   var obj=JSON.parse(ob)
  // collection.find({title:obj.name,by:obj.pass});
   collection.find({}, function(err, result) {
    if (err) throw err;
    console.log("welcome "+result);
    db.close();
  });
  // response.write("Name is-->"+obj.name);
   //response.write("<br>Password is-->"+obj.pass);
}
}
     response.write(data.toString());		
      }
      response.end();
   });   
}).listen(8081);
console.log('Server running');
