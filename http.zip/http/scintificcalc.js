exports.sqrt=function(sinvalue){
	return Math.sqrt(sinvalue);
}
exports.cos=function(sinvalue){
	return Math.cos(sinvalue);
}
exports.sin=function(sinvalue){
	return Math.sin(sinvalue);
}
